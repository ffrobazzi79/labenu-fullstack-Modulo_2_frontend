import { extendTheme } from "@chakra-ui/react"

export const theme = extendTheme({
  colors: {
    vermelho: {
        100: "#f76a6c",
        200: "#fc3d3f",
        300: "#f51618"
    },

    brand: {
      100: "#f7fafc",
      // ...
      900: "#1a202c",
    },
  },
})