import { Cart } from "./components/Cart";
import "./styles.css";

export default function App() {
  return (
    <div>
      <Cart />
    </div>
  );
}
