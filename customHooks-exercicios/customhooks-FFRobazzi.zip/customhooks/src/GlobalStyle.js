import { createGlobalStyle } from 'styled-components';
 
// Estilos definidos aqui serão aplicados a toda a aplicação
export const GlobalStyle = createGlobalStyle`
  body {
    margin: 0;
    padding: 0;
   
  }
 
  
  /* Outros estilos globais */
`;