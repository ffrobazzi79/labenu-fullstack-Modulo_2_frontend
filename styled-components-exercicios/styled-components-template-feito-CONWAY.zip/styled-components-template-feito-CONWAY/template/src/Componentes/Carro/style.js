import styled from "styled-components";


export const CarroContainer = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
`