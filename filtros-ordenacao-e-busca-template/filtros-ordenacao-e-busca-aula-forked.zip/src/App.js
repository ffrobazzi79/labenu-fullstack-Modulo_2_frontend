import styled, { createGlobalStyle } from "styled-components";
import pokemons from "./pokemon/pokemon.json";
import PokemonCard from "./components/PokemonCard/PokemonCard";
import { getColors } from "./utils/ReturnCardColor";
import Header from "./components/Header/Header.js";
import { useState } from "react";
const GlobalStyle = createGlobalStyle`
  *{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-family: "Inter", sans-serif;
  
  }
`;
const CardsContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(440px, 1fr));
  justify-items: center;
`;
function App() {
  const [buscaId, setBuscaId] = useState("");
  const [buscaNome, setBuscaNome] = useState("");
  return (
    <>
      <GlobalStyle />
      <Header
        buscaId={buscaId}
        setBuscaId={setBuscaId}
        buscaNome={buscaNome}
        setBuscaNome={setBuscaNome}
      />
      <CardsContainer>
        {pokemons
          .filter((pokemon) => {
            // exemplo usando ternário
            // return buscaId ? pokemon.id === buscaId : pokemon

            // Exemplo usando if/else
            if (buscaId && pokemon.id === buscaId) {
              return pokemon;
            } else if (!buscaId) {
              return pokemon;
            }
          })
          //Chegou a sua vez de implementar um filtro!
          // Implemente o filtro por nome do Pokemon.
          // Perceba que você pode encadear mais esse filtro logo após o que já implementamos.
          .filter((pokemon) => {
            // exemplo usando ternário
            // return pokemon.name.english.toLowerCase().includes(buscaNome);

            // exemplo usando o if/else
            if (pokemon.name.english.toLowerCase().includes(buscaNome)) {
              return pokemon;
            }
          })
          .map((pokemon) => {
            return (
              <PokemonCard
                cardColor={getColors(pokemon.type[0])}
                key={pokemon.id}
                pokemon={pokemon}
              />
            );
          })}
      </CardsContainer>
    </>
  );
}

export default App;
