import React, { useState } from 'react'
import {MainContainer, Form, Input} from './styles'

function MainPage() {
  
  const [nome, setNome] = useState("")
  const [idade, setIdade] = useState("")

  const mudarNome = (event)=>{
    console.log(event.target.value)
    console.log(nome)
    setNome(event.target.value)
  }
  // console.log(nome)

  const mudarIdade = (e)=>{
    setIdade(e.target.value)
  }

  // (event)=>{setIdade(event.target.value)}
  
  console.log(idade)


  const apagarDados = ()=>{

    const novoUsuario ={
      nome: nome,
      idade: idade
    }

    console.log(novoUsuario)

    setNome("")
    setIdade("")
  }

  

  return (
    <MainContainer>
      <h2>Formulário de inscrição</h2>
      <Form>
        <label>
          Nome:
          <Input value={nome} onChange={mudarNome} />
          Estado nome: {nome}
          <Input />
        </label>
        <label>
          Idade:
          <Input 
            value={idade} 
            onChange={(event)=>{setIdade(event.target.value)}} 
            type="number"
          />
        </label >
      <button onClick={apagarDados}>Enviar dados</button>
      </Form>
    </MainContainer>
  )
}

export default MainPage
