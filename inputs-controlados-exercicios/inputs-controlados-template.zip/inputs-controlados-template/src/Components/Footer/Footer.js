import React from 'react'
import {AllRightsReserved} from './styles'


function Footer(){
  return (
    <AllRightsReserved>All rights reserved</AllRightsReserved>
  )
}

export default Footer