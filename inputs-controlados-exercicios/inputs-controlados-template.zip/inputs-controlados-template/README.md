Template - Inputs controlados


Você pode usar este repositório como template, baixando e rodando `npm install` na pasta correspondente, ou utilizar o `Codesandbox.`
https://codesandbox.io/s/template-inputs-ye8y41?file=/src/App.js
